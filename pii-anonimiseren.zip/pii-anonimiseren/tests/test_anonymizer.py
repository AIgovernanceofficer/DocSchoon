"""
Tests voor de PII-anonimiseringstool.

Draaien met:  pytest -q

De tests die de documenten verwerken gebruiken gestructureerde gegevens
(e-mail, BSN) die ook in de regex-terugval worden gevonden. Ze slagen dus
ook zonder dat het zware spaCy-taalmodel geïnstalleerd is.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.anonymizer import Detection, PIIAnonymizer, resolve_overlaps  # noqa: E402
from src.config import _bsn_is_valid  # noqa: E402
from src.document_handlers import _edit_runs  # noqa: E402


# ---------------------------------------------------------------------------
# Hulpobjecten
# ---------------------------------------------------------------------------
class FakeRun:
    """Bootst een Word/PowerPoint-run na: alleen een .text-attribuut."""

    def __init__(self, text):
        self.text = text


class FakeAnonymizer:
    """Geeft vaste detecties terug, zodat _edit_runs los te testen is."""

    language = "nl"

    def __init__(self, detections):
        self._detections = detections

    def detect(self, text):
        return list(self._detections)


# ---------------------------------------------------------------------------
# BSN-elfproef
# ---------------------------------------------------------------------------
def test_bsn_geldig():
    assert _bsn_is_valid("111222333")  # bekende geldige test-BSN


def test_bsn_ongeldig():
    assert not _bsn_is_valid("123456789")
    assert not _bsn_is_valid("000000000")
    assert not _bsn_is_valid("12345")


# ---------------------------------------------------------------------------
# Overlap-afhandeling
# ---------------------------------------------------------------------------
def test_overlap_hoogste_score_wint():
    dets = [
        Detection(0, 10, "PERSON", 0.5),
        Detection(3, 8, "LOCATION", 0.9),
    ]
    out = resolve_overlaps(dets)
    assert len(out) == 1
    assert out[0].entity_type == "LOCATION"


def test_geen_overlap_blijft_behouden():
    dets = [Detection(0, 3, "PERSON", 0.8), Detection(5, 9, "EMAIL_ADDRESS", 0.8)]
    out = resolve_overlaps(dets)
    assert len(out) == 2


# ---------------------------------------------------------------------------
# Run-bewerking: opmaak (run-grenzen) blijven behouden
# ---------------------------------------------------------------------------
def test_edit_runs_binnen_een_run():
    runs = [FakeRun("Bel Jan Jansen vandaag")]
    # "Jan Jansen" staat op posities 4..14
    anon = FakeAnonymizer([Detection(4, 14, "PERSON", 0.9)])
    result = _Dummy()
    _edit_runs(runs, anon, "tag", result)
    assert runs[0].text == "Bel [NAAM] vandaag"


def test_edit_runs_over_meerdere_runs():
    # "Jan" en " Jansen" in aparte runs (bv. verschillende opmaak)
    runs = [FakeRun("Jan"), FakeRun(" Jansen"), FakeRun(" komt")]
    # "Jan Jansen" = posities 0..10
    anon = FakeAnonymizer([Detection(0, 10, "PERSON", 0.9)])
    result = _Dummy()
    _edit_runs(runs, anon, "tag", result)
    samengevoegd = "".join(r.text for r in runs)
    assert samengevoegd == "[NAAM] komt"


def test_edit_runs_redact_stijl():
    runs = [FakeRun("abc@example.com")]
    anon = FakeAnonymizer([Detection(0, 15, "EMAIL_ADDRESS", 0.9)])
    result = _Dummy()
    _edit_runs(runs, anon, "redact", result)
    assert runs[0].text == "█" * 15


class _Dummy:
    """Minimale ProcessResult-vervanger voor _edit_runs."""

    def __init__(self):
        self.total_replacements = 0
        self.counts_by_type = {}

    def add(self, entity_type, n=1):
        self.total_replacements += n
        self.counts_by_type[entity_type] = self.counts_by_type.get(entity_type, 0) + n


# ---------------------------------------------------------------------------
# Volledige round-trip per bestandstype (met regex-terugval op e-mail/BSN)
# ---------------------------------------------------------------------------
def test_docx_roundtrip(tmp_path):
    from docx import Document

    from src.document_handlers import anonymize_file

    doc = Document()
    doc.add_paragraph("Mail naar piet@example.com over BSN 111222333.")
    src = tmp_path / "test.docx"
    doc.save(src)

    out = tmp_path / "out.docx"
    anon = PIIAnonymizer(language="nl")
    result = anonymize_file(str(src), str(out), anon, "tag")

    text = "\n".join(p.text for p in Document(str(out)).paragraphs)
    assert "piet@example.com" not in text
    assert "111222333" not in text
    assert result.total_replacements >= 2


def test_xlsx_roundtrip(tmp_path):
    from openpyxl import Workbook, load_workbook

    from src.document_handlers import anonymize_file

    wb = Workbook()
    ws = wb.active
    ws["A1"] = "Contact: jan@example.com"
    ws["A2"] = "Gewoon getal 42"
    src = tmp_path / "test.xlsx"
    wb.save(src)

    out = tmp_path / "out.xlsx"
    anon = PIIAnonymizer(language="nl")
    anonymize_file(str(src), str(out), anon, "tag")

    wb2 = load_workbook(str(out))
    ws2 = wb2.active
    assert "jan@example.com" not in str(ws2["A1"].value)
    assert ws2["A2"].value == "Gewoon getal 42"  # ongemoeid gelaten


def test_pptx_roundtrip(tmp_path):
    from pptx import Presentation
    from pptx.util import Inches

    from src.document_handlers import anonymize_file

    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    box = slide.shapes.add_textbox(Inches(1), Inches(1), Inches(6), Inches(1))
    box.text_frame.text = "Bereikbaar via test@example.com"
    src = tmp_path / "test.pptx"
    prs.save(src)

    out = tmp_path / "out.pptx"
    anon = PIIAnonymizer(language="nl")
    anonymize_file(str(src), str(out), anon, "tag")

    prs2 = Presentation(str(out))
    found = []
    for s in prs2.slides:
        for sh in s.shapes:
            if sh.has_text_frame:
                found.append(sh.text_frame.text)
    joined = " ".join(found)
    assert "test@example.com" not in joined
