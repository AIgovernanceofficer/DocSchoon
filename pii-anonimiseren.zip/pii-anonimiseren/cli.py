"""
Opdrachtregel-interface voor de PII-anonimiseringstool.

Voorbeelden:
    python cli.py document.docx
    python cli.py *.docx --taal en --stijl redact --uitvoer schoon/
    python cli.py rapport.xlsx --drempel 0.5

Handig voor batchverwerking of integratie in scripts. Voor losse bestanden is
de webinterface (streamlit run app.py) gebruiksvriendelijker.
"""

from __future__ import annotations

import argparse
import os
import sys

from src import config
from src.anonymizer import PIIAnonymizer
from src.document_handlers import SUPPORTED_EXTENSIONS, anonymize_file


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Verwijder persoonsgegevens uit Word-, PowerPoint-, "
        "Excel- of tekstbestanden.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("bestanden", nargs="+", help="In te lezen bestand(en).")
    parser.add_argument(
        "--taal",
        default=config.DEFAULT_LANGUAGE,
        choices=list(config.LANGUAGE_MODELS.keys()),
        help="Taal van de documenten (standaard: nl).",
    )
    parser.add_argument(
        "--stijl",
        default="tag",
        choices=["tag", "redact"],
        help="tag = label tonen ([NAAM]); redact = zwart maken (████).",
    )
    parser.add_argument(
        "--drempel",
        type=float,
        default=0.4,
        help="Zekerheidsdrempel 0.0–1.0 (standaard: 0.4).",
    )
    parser.add_argument(
        "--uitvoer",
        default=None,
        help="Map voor de schone bestanden (standaard: naast het origineel).",
    )
    args = parser.parse_args()

    anonymizer = PIIAnonymizer(language=args.taal, score_threshold=args.drempel)
    if not anonymizer.uses_ner:
        print(
            "WAARSCHUWING: taalmodel niet gevonden — beperkte modus "
            "(geen namen/locaties). Zie README voor installatie.",
            file=sys.stderr,
        )

    if args.uitvoer:
        os.makedirs(args.uitvoer, exist_ok=True)

    exit_code = 0
    for path in args.bestanden:
        ext = os.path.splitext(path)[1].lower()
        if ext not in SUPPORTED_EXTENSIONS:
            print(f"Overslaan (niet ondersteund): {path}", file=sys.stderr)
            continue
        if not os.path.isfile(path):
            print(f"Niet gevonden: {path}", file=sys.stderr)
            exit_code = 1
            continue

        base, ext = os.path.splitext(os.path.basename(path))
        out_name = f"{base}_geanonimiseerd{ext}"
        out_dir = args.uitvoer or os.path.dirname(os.path.abspath(path))
        out_path = os.path.join(out_dir, out_name)

        try:
            result = anonymize_file(path, out_path, anonymizer, args.stijl)
        except Exception as exc:
            print(f"FOUT bij {path}: {exc}", file=sys.stderr)
            exit_code = 1
            continue

        summary = ", ".join(
            f"{config.label_for(t, args.taal)}={n}"
            for t, n in sorted(result.counts_by_type.items(), key=lambda x: -x[1])
        )
        print(f"{path} -> {out_path}  ({result.total_replacements} vervangingen"
              + (f": {summary}" if summary else "") + ")")

    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
